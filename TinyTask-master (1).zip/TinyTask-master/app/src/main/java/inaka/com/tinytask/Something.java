package inaka.com.tinytask;

public interface Something<T> {

    abstract T whichDoes() throws Exception;

}
